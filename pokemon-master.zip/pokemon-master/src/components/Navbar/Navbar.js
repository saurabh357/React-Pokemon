import React from 'react';
import './style.css';

function Navbar() {
    return (
        <div className="Navbar">
            Pokemon API
        </div>
    );
}

export default Navbar;
